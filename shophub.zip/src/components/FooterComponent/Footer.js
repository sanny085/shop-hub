import React from "react";


function Footer(){
  return(
    <footer className="footer">
      <p>Copyright <span>&copy;</span> 2021 | All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;